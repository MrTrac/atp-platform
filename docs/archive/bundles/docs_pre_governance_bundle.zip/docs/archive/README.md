# Kho lưu tài liệu lịch sử

`docs/archive/` lưu các tài liệu lịch sử, seed bundle, hoặc bản sao cũ không còn là authority path hiện hành.

## Quy tắc sử dụng

- Không dùng tài liệu trong `archive/` làm nguồn authority hiện hành nếu đã có bản mới dưới `architecture/` hoặc `governance/`
- Chỉ chuyển tài liệu vào `archive/` khi authority path mới đã rõ ràng
- Giữ cấu trúc archive đủ rõ để lần theo lịch sử mà không tạo nhầm lẫn với tài liệu active

## Các nhóm archive hiện có

- `governance-seed/` - governance bundle giai đoạn seed hoặc placement proposal ban đầu
- `legacy-top-level-snapshot-docs/` - snapshot bundle từng nằm sai ở top-level `docs/`
