# Chỉ mục decisions

Thư mục này là chỉ mục cho các decision record bổ sung ngoài các freeze artifact chính của kiến trúc ATP.

## Authority hiện tại

Các decision artifact authoritative cho baseline và hardening snapshot hiện nằm dưới:

```text
docs/architecture/
```

## Vai trò của `docs/decisions/`

`docs/decisions/` dùng để:

- chỉ ra authority path hiện hành
- tránh việc decision record bị rải rác không có owner rõ ràng
- làm điểm mở rộng nếu về sau ATP có thêm decision artifact theo domain hoặc theo timeline

## Ghi chú

Khi số lượng decision record tăng lên, thư mục này nên trở thành chỉ mục rõ ràng theo domain, timeline, hoặc release track; không nên tạo thêm authority path song song với `docs/architecture/` nếu chưa có quyết định mới.
