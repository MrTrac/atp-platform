# Tài liệu ATP

Thư mục `docs/` là cây tài liệu authoritative của ATP. Cấu trúc hiện hành được tổ chức quanh các miền sau:

- `architecture/` - tài liệu kiến trúc hiện hành, freeze records, và các snapshot bundle có authority rõ ràng
- `design/` - các model mức thiết kế, vocabulary ổn định, và quy ước đặt tên
- `operators/` - bootstrap, runbook, và hướng dẫn vận hành repo-local
- `decisions/` - chỉ mục cho decision records ngoài các mốc freeze chính
- `governance/` - governance framework và các bundle đang có hiệu lực
- `archive/` - tài liệu lịch sử hoặc bản sao cũ đã bị thay thế về authority path

## Vai trò của thư mục `docs/`

`docs/` không chỉ là nơi mô tả hệ thống. Đây là nơi lưu:

- tài liệu authoritative đang có hiệu lực
- snapshot bundle cho các mốc baseline và hardening
- governance artifact mà user, AI assistants, wrappers, và workflow liên quan phải tuân thủ
- chỉ dẫn authority path để tránh nhầm lẫn giữa tài liệu hiện hành và tài liệu lịch sử

## Quy tắc authority và placement

- Snapshot kiến trúc của ATP phải đặt dưới `docs/architecture/`
- Governance document phải đặt dưới `docs/governance/` theo đúng domain
- Bản sao top-level hoặc bundle cũ không còn là authority path phải chuyển sang `docs/archive/`
- Không tạo vocabulary top-level mới nếu chưa có decision rõ ràng

## Chuẩn biên tập tài liệu hiện hành

Tài liệu ATP đang có hiệu lực phải tuân theo các nguyên tắc sau:

- viết bằng tiếng Việt Unicode có dấu rõ ràng
- giữ các English technical terms cần thiết ở nguyên dạng khi điều đó giúp chính xác hơn
- phản ánh ATP MVP v0 như một baseline đã hoàn tất đến M8, không dùng future tense cho phần đã triển khai
- self-review ít nhất 2 pass trước khi coi là hoàn tất
- dùng terminology ổn định như `artifact`, `authoritative`, `approval gate`, `finalization`, `evidence bundle`, `exchange bundle`, `manifest reference`
